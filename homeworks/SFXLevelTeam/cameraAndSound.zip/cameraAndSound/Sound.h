#ifndef SOUND_H
#define SOUND_H

class Sound{ 

public:
	Sound();
	~Sound();

	void playSFX();
	void playMusic();

private:

	
};

#endif